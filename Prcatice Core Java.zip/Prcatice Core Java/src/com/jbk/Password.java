package com.jbk;
import java.util.Scanner;

public class Password {
	
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Your Password : ");
		String password = sc.next();
		
		String letters=" ", numbers =" " , Characters=" ";
		
		for(int i=0;i< password.length();i++) {
			
			char ch = password.charAt(i);
			
			if(Character.isLetter(ch)) {
				letters+= ch;
			}else if(Character.isDigit(ch)){
				numbers+=ch;
				
			}else {
				Characters+=ch;
			}
		}
		
		System.out.println("Letters : " + letters);
		System.out.println("Numbers : " + numbers);
        System.out.println("Special Caharacter : " + Characters);		
	}

}
